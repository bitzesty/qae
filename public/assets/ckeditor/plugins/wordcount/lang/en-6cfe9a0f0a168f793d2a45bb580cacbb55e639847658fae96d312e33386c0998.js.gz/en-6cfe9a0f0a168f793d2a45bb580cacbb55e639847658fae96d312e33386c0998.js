/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('wordcount', 'en', {
    WordCount: 'Words:',
    CharCount: 'Characters:',
    CharCountWithHTML: 'Characters (with HTML):',
    Paragraphs: 'Paragraphs:',
    pasteWarning: 'Content cannot be pasted because it is above the allowed limit',
    Selected: 'Selected: ',
    title: 'Statistics'
});
